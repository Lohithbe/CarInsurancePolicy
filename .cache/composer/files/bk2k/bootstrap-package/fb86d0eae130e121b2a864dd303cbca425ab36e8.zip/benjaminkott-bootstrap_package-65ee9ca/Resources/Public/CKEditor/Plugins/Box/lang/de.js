CKEDITOR.plugins.setLang(
    'bootstrappackage_box',
    'de',
    {
        toolbar: 'Box'
    }
);
