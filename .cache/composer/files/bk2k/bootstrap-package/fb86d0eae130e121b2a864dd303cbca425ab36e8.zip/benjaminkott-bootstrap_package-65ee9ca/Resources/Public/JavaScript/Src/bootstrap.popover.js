$(function () {

    /**
     * Opt-in, all popovers
     */
    $('[data-toggle="popover"]').popover()

});
