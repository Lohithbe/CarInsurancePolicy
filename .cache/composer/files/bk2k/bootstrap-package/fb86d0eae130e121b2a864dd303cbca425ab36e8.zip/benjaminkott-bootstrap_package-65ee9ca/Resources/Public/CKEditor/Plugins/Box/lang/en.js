CKEDITOR.plugins.setLang(
    'bootstrappackage_box',
    'en',
    {
        toolbar: 'Box'
    }
);
