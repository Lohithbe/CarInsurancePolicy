<?php
declare(strict_types=1);
namespace In2code\Femanager\Domain\Model;

use TYPO3\CMS\Extbase\Domain\Model\FrontendUserGroup;

/**
 * Class UserGroup
 */
class UserGroup extends FrontendUserGroup
{
}
