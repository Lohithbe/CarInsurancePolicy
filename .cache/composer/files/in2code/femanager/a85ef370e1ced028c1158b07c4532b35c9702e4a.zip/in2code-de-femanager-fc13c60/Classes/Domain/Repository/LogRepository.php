<?php
declare(strict_types=1);
namespace In2code\Femanager\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Class LogRepository
 */
class LogRepository extends Repository
{
}
