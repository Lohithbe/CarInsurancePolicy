.. include:: ../Includes.txt

.. _features:

Features
========

See some features or best practice parts of the extension femanager.

.. toctree::
	:maxdepth: 3
	:titlesonly:
	:glob:

	Templates/Index
	Countryselect/Index
	NewFields/Index
	NewValidators/Index
	AutoConfirmation/Index
	Finishers/Index
	Signals/Index
